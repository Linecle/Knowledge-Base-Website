// Event listener for the "Search" button click
document.getElementById('search-btn').addEventListener('click', function() {
    var query = document.getElementById('search-input').value.toLowerCase();
    var articles = document.querySelectorAll('.article');  // Assuming each article has the 'article' class

    articles.forEach(function(article) {
        var title = article.querySelector('.article-link').textContent.toLowerCase();
        if (title.indexOf(query) !== -1) {
            article.style.display = 'block';  // Show matching article
        } else {
            article.style.display = 'none';   // Hide non-matching article
        }
    });
});

// Real-time search: event listener for the input field
document.getElementById('search-input').addEventListener('input', function() {
    var query = this.value.toLowerCase();
    var articles = document.querySelectorAll('.article');  // Assuming each article has the 'article' class

    articles.forEach(function(article) {
        var title = article.querySelector('.article-link').textContent.toLowerCase();
        if (title.indexOf(query) !== -1) {
            article.style.display = 'block';  // Show matching article
        } else {
            article.style.display = 'none';   // Hide non-matching article
        }
    });
});
