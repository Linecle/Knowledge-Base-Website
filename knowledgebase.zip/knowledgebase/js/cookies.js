// Get references to elements
const banner = document.getElementById('cookie-banner');
const toggleBtn = document.getElementById('toggle-banner');
const closeBtn = document.getElementById('close-banner');
const acceptBtn = document.getElementById('accept-cookies');
const rejectBtn = document.getElementById('reject-cookies');
const analyticalCheckbox = document.getElementById('toggle-analytical');
const marketingCheckbox = document.getElementById('toggle-marketing');

// Function to load Google Analytics (replace with your actual GA ID)
function loadAnalytics() {
  if (typeof window.ga !== 'undefined') {
    ga('create', 'UA-XXXXXXXXX-X', 'auto'); // Replace with your GA ID
    ga('send', 'pageview');
  } else {
    console.warn('Google Analytics not loaded.');
  }
}

// Function to load Google Ads tracking (replace with your actual Google Ads ID)
function loadMarketingTracking() {
  if (!window.gtag) {
    const script = document.createElement('script');
    script.src = 'https://www.googletagmanager.com/gtag/js?id=AW-XXXXXXXXX'; // Replace with your Google Ads ID
    document.head.appendChild(script);

    script.onload = function () {
      window.dataLayer = window.dataLayer || [];
      function gtag() { dataLayer.push(arguments); }
      gtag('js', new Date());
      gtag('config', 'AW-XXXXXXXXX');  // Replace with your Google Ads ID
    };
  } else {
    console.warn('Google Ads tracking already initialized.');
  }
}

// Check if the user has already accepted/rejected cookies
if (!localStorage.getItem('cookieConsent')) {
  // Show the banner if no previous consent was given
  banner.classList.add('open');
  
  // Enable both cookies by default if no previous preference
  analyticalCheckbox.checked = true;
  marketingCheckbox.checked = true;
} else {
  // Apply saved preferences if available
  const preferences = JSON.parse(localStorage.getItem('cookiesPreferences'));
  if (preferences) {
    analyticalCheckbox.checked = preferences.analytical;
    marketingCheckbox.checked = preferences.marketing;
  }
}

// Toggle the visibility of the cookie banner when the settings button is clicked
toggleBtn.addEventListener('click', () => {
  banner.classList.toggle('open');
});

// Close the cookie banner when the close button is clicked
closeBtn.addEventListener('click', () => {
  banner.classList.remove('open');
});

// Accept cookies
acceptBtn.addEventListener('click', () => {
  localStorage.setItem('cookieConsent', 'accepted'); // Mark cookies as accepted
  const preferences = {
    analytical: analyticalCheckbox.checked,
    marketing: marketingCheckbox.checked
  };
  localStorage.setItem('cookiesPreferences', JSON.stringify(preferences)); // Save preferences to localStorage
  banner.classList.remove('open'); // Hide the banner

  // Load analytics and marketing scripts based on user preferences
  if (preferences.analytical) loadAnalytics();
  if (preferences.marketing) loadMarketingTracking();
});

// Reject cookies
rejectBtn.addEventListener('click', () => {
  localStorage.setItem('cookieConsent', 'rejected'); // Mark cookies as rejected
  banner.classList.remove('open'); // Hide the banner
});

// Save user preferences when the toggle switches (checkboxes) are changed
analyticalCheckbox.addEventListener('change', savePreferences);
marketingCheckbox.addEventListener('change', savePreferences);

function savePreferences() {
  const preferences = {
    analytical: analyticalCheckbox.checked,
    marketing: marketingCheckbox.checked
  };
  localStorage.setItem('cookiesPreferences', JSON.stringify(preferences)); // Save preferences to localStorage
}
