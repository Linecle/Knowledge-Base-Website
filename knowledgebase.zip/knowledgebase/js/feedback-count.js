 // Start of Feedback Count
// On page load, initialize the counter to 0 (if it hasn't already been initialized).
window.onload = function() {
    // Load the current "Yes" count from the server
    fetch('get_feedback_count.php')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                document.getElementById('yes-counter').textContent = data.yes_count;
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
};

// This function sends feedback to the PHP script and updates the counter accordingly.
function submitFeedback(answer) {
    // Only send feedback if it's "Yes"
    if (answer === 'Yes') {
        // Check if feedback has already been submitted by this user (via session)
        fetch('check_feedback_submission.php')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'error') {
                alert('You have already submitted feedback!');
                return; // Stop the feedback process if already submitted
            }

            // Send feedback to the PHP script
            fetch('submit_feedback.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ feedback: answer })
            })
            .then(response => response.json())
            .then(data => {
                // Only update the counter when the feedback is successfully submitted
                if (data.status === 'success') {
                    updateCounters();
                    alert('Feedback submitted!');
                } else {
                    alert('Error submitting feedback.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    } else {
        alert('Only "Yes" feedback is recorded.');
    }
}

// Function to update the Yes counter
function updateCounters() {
    let yesCount = parseInt(document.getElementById('yes-counter').textContent);
    yesCount += 1; // Increase the Yes count by 1
    document.getElementById('yes-counter').textContent = yesCount;
}
        // End of Feedback Count