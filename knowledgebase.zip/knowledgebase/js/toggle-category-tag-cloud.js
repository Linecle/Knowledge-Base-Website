// Start of Toggle Category & Toggle Tag Cloud
document.querySelectorAll('.toggle-category').forEach(function (el) {
    el.addEventListener('click', function () {
        this.classList.toggle('closed');
        const categoryList = this.nextElementSibling;
        categoryList.style.display = categoryList.style.display === 'none' ? 'block' : 'none';

        const arrow = this.querySelector('.toggle-arrow i');
        if (categoryList.style.display === 'none') {
            arrow.classList.remove('fa-chevron-up');
            arrow.classList.add('fa-chevron-down');
        } else {
            arrow.classList.remove('fa-chevron-down');
            arrow.classList.add('fa-chevron-up');
        }
    });
});

document.querySelectorAll('.toggle-tag-cloud').forEach(function (el) {
    el.addEventListener('click', function () {
        this.classList.toggle('closed');
        const tagCloud = this.nextElementSibling;
        tagCloud.style.display = tagCloud.style.display === 'none' ? 'block' : 'none';

        const arrow = this.querySelector('.toggle-arrow i');
        if (tagCloud.style.display === 'none') {
            arrow.classList.remove('fa-chevron-up');
            arrow.classList.add('fa-chevron-down');
        } else {
            arrow.classList.remove('fa-chevron-down');
            arrow.classList.add('fa-chevron-up');
        }
    });
});
        // End of Toggle Category & Toggle Tag Cloud