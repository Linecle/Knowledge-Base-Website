window.onload = function() {
  // Hide the spinner when the page is fully loaded
  document.getElementById("spinner").style.display = "none";
};