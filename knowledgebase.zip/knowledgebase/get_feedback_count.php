<?php
// Path to the CSV file where feedback is stored
$file = 'feedback.csv';

// Initialize the "Yes" counter
$yes_count = 0;

// Open the CSV file for reading
if (($file_handle = fopen($file, 'r')) !== false) {
    // Read each row from the CSV file
    while (($data = fgetcsv($file_handle)) !== false) {
        // $data[1] holds the feedback (Yes or No)
        if ($data[1] === 'Yes') {
            $yes_count++;
        }
    }
    
    // Close the file after reading
    fclose($file_handle);
    
    // Return the count of "Yes" responses as a JSON response
    echo json_encode(['status' => 'success', 'yes_count' => $yes_count]);
} else {
    // If the file cannot be opened
    echo json_encode(['status' => 'error', 'message' => 'Failed to open feedback file']);
}
?>
