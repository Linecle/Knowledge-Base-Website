<?php
session_start(); // Start the session

// Check if the feedback has already been submitted by this user (using PHP session)
if (isset($_SESSION['feedback_submitted']) && $_SESSION['feedback_submitted'] === true) {
    echo json_encode(['status' => 'error', 'message' => 'Feedback already submitted']);
} else {
    echo json_encode(['status' => 'success', 'message' => 'Feedback not submitted']);
}
?>
