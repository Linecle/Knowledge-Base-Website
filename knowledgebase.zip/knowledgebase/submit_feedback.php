<?php
session_start(); // Start the session

// Path to the CSV file where feedback will be stored
$file = 'feedback.csv';

// Check if the received data is in JSON format (sent by JavaScript)
$input = json_decode(file_get_contents('php://input'), true);

// Check if the feedback data is present
if (isset($input['feedback'])) {
    // Get the feedback response (Yes or No)
    $feedback = $input['feedback'];

    // Only record "Yes" feedback
    if ($feedback !== 'Yes') {
        echo json_encode(['status' => 'error', 'message' => 'Only "Yes" feedback is recorded']);
        exit;
    }

    // Check if the user has already submitted feedback (using PHP session)
    if (isset($_SESSION['feedback_submitted']) && $_SESSION['feedback_submitted'] === true) {
        echo json_encode(['status' => 'error', 'message' => 'You have already submitted feedback.']);
        exit;
    }

    // Get the current timestamp
    $timestamp = date('Y-m-d H:i:s');

    // Get the user's IP address (optional)
    $user_ip = $_SERVER['REMOTE_ADDR'];

    // Open the CSV file for appending data
    $file_handle = fopen($file, 'a');

    // Check if the file opened successfully
    if ($file_handle !== false) {
        // Prepare the data to be written to the CSV (timestamp, feedback, IP address)
        $data = array($timestamp, $feedback, $user_ip);

        // Write the data to the CSV file
        fputcsv($file_handle, $data);

        // Close the file after writing
        fclose($file_handle);

        // Mark session as feedback submitted
        $_SESSION['feedback_submitted'] = true;

        // Respond back with a success message
        echo json_encode(['status' => 'success', 'message' => 'Feedback recorded']);
    } else {
        // If the file cannot be opened
        echo json_encode(['status' => 'error', 'message' => 'Failed to open feedback file']);
    }
} else {
    // If no feedback was sent
    echo json_encode(['status' => 'error', 'message' => 'No feedback received']);
}
?>
